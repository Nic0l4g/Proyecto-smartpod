# AppAndroidStudio-Java
Aplicación móvil con login y registro de gimnasio con ejercicios de tren superior e inferior, programada con Java, se implementa firebase, creada en Android Studio 

La app permite la creacion de usuario, como usuario de prueba se puede usar usuario: c@gmail.com y contraseña: 123456
Proyecto en Figma:  https://www.figma.com/file/HtgiV1EqFWlU60yDJHbckV/Gym-App?type=design&node-id=0-1&t=afrr44iS1lOiwlk9-0

